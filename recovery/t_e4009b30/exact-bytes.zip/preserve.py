import hashlib
import json
import os
from pathlib import Path
import subprocess
import zipfile

SOURCE = Path('C:/Users/bkam/Development/dwc-website/.worktrees/t_e0492ffe')
OUT = Path(__file__).resolve().parent / 'preservation'
HEAD = 'c1d4939a1598a98e387fd112d2a758595136caae'
REF = 'refs/heads/recovery/t_e0492ffe-c1d4939a-t_bacd69cb'
PATHS = ['review-evidence/home-1280.png', 'review-evidence/home-320.png', 'review-evidence/home-640.png', 'review-evidence/keyboard-tastings.png']
ENV = dict(os.environ, GIT_TERMINAL_PROMPT='0', GCM_INTERACTIVE='Never', GIT_OPTIONAL_LOCKS='0')

def git(*args):
    return subprocess.check_output(['git', '-C', str(SOURCE), *args], env=ENV, timeout=90).decode().strip()

def snapshot():
    files = []
    for name in PATHS:
        p = SOURCE / name
        assert p.is_file() and not p.is_symlink(), name
        data = p.read_bytes()
        files.append({'path': name, 'size': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
    return {'head': git('rev-parse', 'HEAD'), 'status': git('status', '--porcelain=v1', '--untracked-files=all'), 'files': files}

if __name__ == '__main__':
    import sys
    if sys.argv[1] == 'archive':
        before = snapshot()
        assert before['head'] == HEAD
        assert git('rev-parse', '--abbrev-ref', 'HEAD') == 'HEAD'
        assert set(before['status'].splitlines()) == {'?? ' + p for p in PATHS}
        remote = git('remote', 'get-url', 'origin')
        assert remote in ('https://github.com/DeliciousHouse/dwc-website.git', 'git@github.com:DeliciousHouse/dwc-website.git')
        pr = json.loads(subprocess.check_output(['gh', 'pr', 'view', '22', '--repo', 'DeliciousHouse/dwc-website', '--json', 'number,state,headRefOid,mergeCommit,mergedAt'], env=ENV, timeout=60))
        assert pr['state'] == 'MERGED' and pr['headRefOid'] == HEAD
        assert pr['mergeCommit']['oid'] == '31262879f4af71c54a1b5231a724ebedf58eb579'
        assert git('cat-file', '-t', HEAD) == 'commit'
        OUT.mkdir(exist_ok=False)
        manifest = {'source': str(SOURCE), 'source_head': HEAD, 'recovery_ref': REF, 'pr': pr, 'files': before['files']}
        manifest_bytes = (json.dumps(manifest, indent=2) + '\n').encode()
        (OUT / 'manifest.json').write_bytes(manifest_bytes)
        (OUT / 'before.json').write_text(json.dumps(before, indent=2) + '\n')
        archive = OUT / 't_e0492ffe-review-screenshots.zip'
        with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as z:
            for item in before['files']:
                z.write(SOURCE / item['path'], item['path'])
            z.writestr('manifest.json', manifest_bytes)
        extracted = OUT / 'extracted'
        with zipfile.ZipFile(archive) as z:
            assert set(z.namelist()) == set(PATHS + ['manifest.json'])
            assert z.testzip() is None
            z.extractall(extracted)
        for item in before['files']:
            data = (extracted / item['path']).read_bytes()
            assert data == (SOURCE / item['path']).read_bytes()
            assert len(data) == item['size'] and hashlib.sha256(data).hexdigest() == item['sha256']
        assert (extracted / 'manifest.json').read_bytes() == manifest_bytes
        assert snapshot() == before
        print(json.dumps({'archive': str(archive), 'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'files': before['files'], 'exact_extraction_verified': True}, indent=2))
    elif sys.argv[1] == 'verify':
        before = json.loads((OUT / 'before.json').read_text())
        assert snapshot() == before
        remote = git('ls-remote', '--heads', 'origin', REF)
        assert remote.split() == [HEAD, REF], remote
        receipt = {'originals_unchanged': True, 'head': HEAD, 'recovery_ref': REF, 'ls_remote': remote, 'archive_sha256': hashlib.sha256((OUT / 't_e0492ffe-review-screenshots.zip').read_bytes()).hexdigest(), 'files': before['files']}
        (OUT / 'verification.json').write_text(json.dumps(receipt, indent=2) + '\n')
        print(json.dumps(receipt, indent=2))
    else:
        raise ValueError('archive or verify required')
